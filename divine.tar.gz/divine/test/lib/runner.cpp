#include <brick-shelltest>

int main( int argc, const char **argv ) {
    return brick::shelltest::run( argc, argv );
}
