/* VERIFY_OPTS: -std=c++11 */

#include <cassert>

int main() {
    assert( __cplusplus == 201103L );
}
