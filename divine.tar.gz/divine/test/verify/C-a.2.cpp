/* VERIFY_OPTS: -C -include,inc.h,-I`dirname $1` */

int main() {
    return foo();
}
