/* VERIFY_OPTS: -std=c++98 */

#include <cassert>

int main() {
    assert( __cplusplus == 199711L );
}
