/* VERIFY_OPTS: -std=c++14 */

#include <cassert>

int main() {
    assert( __cplusplus == 201402L );
}
