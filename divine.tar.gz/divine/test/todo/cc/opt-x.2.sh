. lib/testcase

touch empty
divine cc -x c empty
