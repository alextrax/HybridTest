#include <stdlib.h>

int main()
{
    exit( 0 );
    assert( 0 );
    return 0;
}
