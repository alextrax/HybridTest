#include <divine.h>

void __boot() {}
int main() {}
