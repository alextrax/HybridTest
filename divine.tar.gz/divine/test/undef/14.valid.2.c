#include <stdlib.h>

int main() {
    int x;
    x = 42;
    if ( x == 0 )
        exit( 1 );
    return 0;
}
