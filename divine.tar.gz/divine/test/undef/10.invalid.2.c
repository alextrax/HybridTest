#include <stdlib.h>

int main() {
    float x, y = 1;
    if ( x == y ) /* ERROR */
        exit( 1 );
    return 0;
}
