#include <stdlib.h>

int main() {
    int x = 1, y;
    if ( x == y ) /* ERROR */
        exit( 1 );
    return 0;
}
