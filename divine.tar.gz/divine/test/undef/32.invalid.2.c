/* ERRSPEC: _PDCLIB_Exit */
void main() {
}
