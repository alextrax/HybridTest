#include <stdlib.h>

int main() {
    float x, y;
    if ( x == y ) /* ERROR */
        exit( 1 );
    return 0;
}
