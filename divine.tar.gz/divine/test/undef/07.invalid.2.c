#include <stdlib.h>

int main() {
    int x, y;
    if ( x == y ) /* ERROR */
        exit( 1 );
    return 0;
}
