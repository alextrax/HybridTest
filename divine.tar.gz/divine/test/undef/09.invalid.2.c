#include <stdlib.h>

int main() {
    int x, y = 1;
    if ( x == y ) /* ERROR */
        exit( 1 );
    return 0;
}
