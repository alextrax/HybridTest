#include <stdlib.h>

int main() {
    short x = 42;
    int y = x;
    if ( y == 0 )
        exit( 1 );
    return 0;
}
