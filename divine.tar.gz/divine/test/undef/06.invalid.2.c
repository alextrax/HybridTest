#include <stdlib.h>

int main() {
    int x;
    if ( !x ) /* ERROR */
        exit( 1 );
    return 0;
}
