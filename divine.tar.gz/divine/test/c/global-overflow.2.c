int array[2];

int main() {
    array[2] = 3; /* ERROR: bad dereference */
    return 0;
}
