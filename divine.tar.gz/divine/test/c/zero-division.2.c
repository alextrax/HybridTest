int main()
{
    int a = 4;
    a = a / 0; /* ERROR: division by zero */
    return 0;
}
