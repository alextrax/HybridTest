#include <assert.h>
int main()
{
    int a = -1;
    assert( a < 0 );
    return 0;
}
