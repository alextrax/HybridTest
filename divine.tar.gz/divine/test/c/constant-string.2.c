int main() {
    char *data = "some string";
    data[3] = 'x'; /* ERROR */
}
