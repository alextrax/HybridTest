#include <assert.h>

int main()
{
    assert( 0 ); /* ERROR */
    return 0;
}
