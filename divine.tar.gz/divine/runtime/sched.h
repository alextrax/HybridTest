#include <divine.h>

#ifdef __cplusplus
extern "C"
#endif
int sched_yield( void );
